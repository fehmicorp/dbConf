import { NextRequest, NextResponse } from "next/server";
export default function handlePatch(req: NextRequest): Promise<NextResponse<{
    success: boolean;
    method: string;
    result: any;
}>>;
