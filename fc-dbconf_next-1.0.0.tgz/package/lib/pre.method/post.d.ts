import { BodyTypes, ResultType } from '../utils/data.type';
import { NextRequest } from "next/server";
export default function handlePost(req: NextRequest): Promise<import("next/server").NextResponse<{
    data?: string | number | Record<string, unknown> | unknown[] | undefined;
    msg?: string | undefined;
    success: boolean;
}>>;
export declare function graphQL(redis: any, body: BodyTypes): Promise<ResultType>;
export declare function restApi(redis: any, body: BodyTypes): Promise<ResultType>;
