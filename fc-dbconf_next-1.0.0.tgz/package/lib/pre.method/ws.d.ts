import { redisData } from "../utils/header";
export declare function handleWS(req: any): Promise<import("next/server").NextResponse<{
    success: boolean;
    error: any;
}> | {
    success: boolean;
    config: typeof redisData;
    handler: (clientPayload: any) => Promise<import("../utils/data.type").ResultType>;
}>;
