import { NextRequest, NextResponse } from "next/server";
export default function handleGet(req: NextRequest): Promise<NextResponse<{
    success: boolean;
    method: string;
}>>;
