import { NextRequest, NextResponse } from "next/server";
export default function handlePut(req: NextRequest): Promise<NextResponse<{
    success: boolean;
    method: string;
    result: any;
}>>;
