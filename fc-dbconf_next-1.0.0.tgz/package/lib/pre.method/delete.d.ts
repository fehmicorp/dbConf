import { NextRequest, NextResponse } from "next/server";
export default function handleDelete(req: NextRequest): Promise<NextResponse<{
    success: boolean;
    method: string;
}>>;
