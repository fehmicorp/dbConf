import { BodyTypes, DbConf, InputTypes, QueryTypes, ResultType } from "../utils/data.type";
export declare const fetchDb: (dbConf: DbConf, query: QueryTypes, input: InputTypes, body: BodyTypes) => Promise<ResultType>;
