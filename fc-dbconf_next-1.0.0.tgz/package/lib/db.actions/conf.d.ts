import { Pool } from "pg";
import { DbConf } from "../utils/data.type";
export declare function getDbPool(dbConf: DbConf): Pool;
