export declare class WebSokcet {
    static handle(req: any): Promise<import("next/server").NextResponse<{
        success: boolean;
        error: any;
    }> | {
        success: boolean;
        config: typeof import("./utils/header").redisData;
        handler: (clientPayload: any) => Promise<import("./utils/data.type").ResultType>;
    }>;
}
