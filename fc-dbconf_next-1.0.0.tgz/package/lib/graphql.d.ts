export declare class GraphQL {
    static handle(req: any): Promise<import("next/server").NextResponse<{
        data?: string | number | Record<string, unknown> | unknown[] | undefined;
        msg?: string | undefined;
        success: boolean;
    }> | import("next/server").NextResponse<{
        success: boolean;
        error: any;
    }>>;
}
