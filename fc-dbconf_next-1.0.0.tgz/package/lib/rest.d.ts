import { NextRequest } from "next/server";
export declare class Rest {
    static handle(req: NextRequest): Promise<import("next/server").NextResponse<{
        data?: string | number | Record<string, unknown> | unknown[] | undefined;
        msg?: string | undefined;
        success: boolean;
    }> | import("next/server").NextResponse<{
        success: boolean;
        error: any;
    }> | import("next/server").NextResponse<{
        success: boolean;
        method: string;
    }>>;
}
