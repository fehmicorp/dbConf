import { NextResponse } from "next/server";
import { ResultDataTypes } from "../utils/data.type";
export declare class Response {
    static res(success: boolean, msg: string | null, data: ResultDataTypes | null, status?: number): NextResponse<{
        data?: string | number | Record<string, unknown> | unknown[] | undefined;
        msg?: string | undefined;
        success: boolean;
    }>;
    static error(error: any, status?: number): NextResponse<{
        success: boolean;
        error: any;
    }>;
    static redirect(url: string, status?: number): NextResponse<unknown>;
    static custom(body: any, status?: number, headers?: HeadersInit): NextResponse<unknown>;
}
