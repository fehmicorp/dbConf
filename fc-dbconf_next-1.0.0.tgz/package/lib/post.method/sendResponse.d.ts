import { ResultType } from "../utils/data.type";
export default function sendResponse(result: ResultType): import("next/server").NextResponse<{
    data?: string | number | Record<string, unknown> | unknown[] | undefined;
    msg?: string | undefined;
    success: boolean;
}>;
