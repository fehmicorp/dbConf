export declare function redisData(req: any): Promise<any>;
