import { QuerySelectTypes, QueryTypes, QueryConditions, InputTypes, BodyTypes, InptAuthTypes, QueryWhereTypes } from "./data.type";
export declare const buildQuery: (query: any, auth: InptAuthTypes | null) => string;
export declare const prepareQuery: (query: QueryTypes, input: InputTypes | null, body: BodyTypes) => {
    sql: string;
    values: any[];
    auth: Record<string, string> | null;
};
export declare const buildSelect: (select: QuerySelectTypes, auth: InptAuthTypes) => string;
export declare const buildWhere: (where?: QueryWhereTypes) => string | null;
export declare const whereAND: (condition: QueryConditions) => string;
export declare const whereOR: (condition: QueryConditions) => string;
