export declare function verifyPassword(row: any, auth: any, body: any): Promise<any | null>;
