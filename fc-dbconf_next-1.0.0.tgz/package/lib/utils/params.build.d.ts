import { BodyTypes, InputMapTypes, InputRequiredTypes } from "./data.type";
export declare const buildIdentityParams: (body: BodyTypes, input: {
    required?: InputRequiredTypes;
    map?: InputMapTypes;
}) => Record<string, any>;
